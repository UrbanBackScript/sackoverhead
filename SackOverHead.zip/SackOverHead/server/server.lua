ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


ESX.RegisterUsableItem("sack", function(source)
local xPlayer = ESX.GetPlayerFromId(source)
local inventory = xPlayer.getInventoryItem('sack').count
if inventory >= 1 then
xPlayer.removeInventoryItem("sack", 1)
TriggerClientEvent("sackoverhead:check", source, source)
else
--print("Du hast kein Sack Item!")
end
end)

RegisterCommand("sack", function(source, args, rawCommand)
local xPlayer = ESX.GetPlayerFromId(source)
local inventory = xPlayer.getInventoryItem('sack').count
if inventory >= 1 then
xPlayer.removeInventoryItem("sack", 1)
TriggerClientEvent("sackoverhead:check", source)
else
--print("Du hast kein Sack Item!")
end
end, false) -- this to false to allow anyone to use.

RegisterNetEvent("sackoverhead:playercheck")
AddEventHandler("sackoverhead:playercheck", function(player, getcommandplayer)
TriggerClientEvent("sackoverhead:finish", player, getcommandplayer)
end)

RegisterNetEvent("sackoverhead:fullcheck")
AddEventHandler("sackoverhead:fullcheck", function(getcommandplayer, cuffed)

    if cuffed then
    print(getcommandplayer)
    local xPlayer = ESX.GetPlayerFromId(getcommandplayer)
    xPlayer.addInventoryItem("sack",2)
    end

end)