window.addEventListener('message', (event) => {
	let data = event.data
	
	if(data.action === "enable") {
	$("body").show();
	}

	if(data.action === "disable") {
		$("body").hide();
	}
})