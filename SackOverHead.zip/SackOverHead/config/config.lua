Config =  {}

Config.SetNotificationText = "Du hast ein Sack item benutzt!" -- Here you can edit your Notify Text! --

Config.EnableNotifyText = true -- true = NotifyText will be show || false = Notify Text will not be show! --