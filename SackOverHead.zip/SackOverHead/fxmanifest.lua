fx_version 'adamant'

game 'gta5'

description '[By UrbanBack]'

version '1.0.0'

server_scripts {
    "server/server.lua"
}

client_scripts {
	"config/config.lua",
	"client/client.lua"
}

ui_page '/html/index.html'

files {
	'/html/index.html',
	'/html/app.js',
	'/html/style.css'
}

lua54 'yes'

escrow_ignore {
	'config/config.lua'
  }