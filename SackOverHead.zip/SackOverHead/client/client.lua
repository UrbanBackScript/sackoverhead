ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local cuffed = false

RegisterNetEvent("sackoverhead:check")
AddEventHandler("sackoverhead:check", function(getcommandplayer)
    local player, distance = ESX.Game.GetClosestPlayer()
    if distance~=-1 and distance<=3.0 then
    TriggerServerEvent("sackoverhead:playercheck", GetPlayerServerId(player), getcommandplayer)
    if Config.EnableNotifyText then
    ESX.ShowNotification(Config.SetNotificationText)
    end
else
-- Keine Spieler in der Nähe --
end
end)

RegisterNetEvent("sackoverhead:finish")
AddEventHandler("sackoverhead:finish", function(getcommandplayer)
    if cuffed then
        SendNUIMessage({
            action = "disable"
        })
        print("disabled!")
        TriggerServerEvent("sackoverhead:fullcheck", getcommandplayer, cuffed)
        cuffed = false
    else
        SendNUIMessage({
            action = "enable"
        })
        print("enabled!")
        cuffed = true
    end
end)

Citizen.CreateThread(function()
    local playerPed = GetPlayerPed(-1)
    if cuffed then
        ClearPedTasks(playerPed)
        Citizen.Wait(10)
        DisablePlayerFiring(playerPed, true)
        SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'), true)
        DisplayRadar(false)
        DisableControlAction(0, 140, true)
        DisableControlAction(0, 74, true)
        DisableControlAction(0, 2, true) -- Disable pan
        DisableControlAction(0, 263, true) -- Melee Attack 1
        DisableControlAction(0, 45, true) -- Reload
        DisableControlAction(0, 22, true) -- Jump
        DisableControlAction(0, 44, true) -- Cover
        DisableControlAction(0, 37, true) -- Select Weapon
        DisableControlAction(0, 288,  true) -- Disable phone
        DisableControlAction(0, 289, true) -- Inventory
        DisableControlAction(0, 170, true) -- Animations
        DisableControlAction(0, 167, true) -- Job
        DisableControlAction(1, 254, true)
        DisableControlAction(0, 47, true)  -- Disable weapon
        DisableControlAction(0, 73, true)  -- Tab Menü deaktivieren
        DisablePlayerFiring(PlayerId(), true) -- Deaktiviert das Feuern
        DisableControlAction(0, 140, true) -- Deaktiviert die Taste R
    else
        Citizen.Wait(10)
        DisablePlayerFiring(playerPed, false)
        DisplayRadar(true)
        DisableControlAction(0, 140, false)
        DisableControlAction(0, 74, false)
        DisableControlAction(0, 2, false) -- Disable pan
        DisableControlAction(0, 263, false) -- Melee Attack 1
        DisableControlAction(0, 45, false) -- Reload
        DisableControlAction(0, 22, false) -- Jump
        DisableControlAction(0, 44, false) -- Cover
        DisableControlAction(0, 37, false) -- Select Weapon
        DisableControlAction(0, 288,  false) -- Disable phone
        DisableControlAction(0, 289, false) -- Inventory
        DisableControlAction(0, 170, false) -- Animations
        DisableControlAction(0, 167, false) -- Job
        DisableControlAction(1, 254, false)
        DisableControlAction(0, 47, false)  -- Disable weapon
        DisableControlAction(0, 73, false)  -- Tab Menü deaktivieren
        DisablePlayerFiring(PlayerId(), false) -- Deaktiviert das Feuern
        DisableControlAction(0, 140, false) -- Deaktiviert die Taste R
    end
end)